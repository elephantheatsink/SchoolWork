package com.mycompany.a2;

public interface IMovable {		//movable interface
	void move();				//every class that implements this interface has a move method
	
	
}
