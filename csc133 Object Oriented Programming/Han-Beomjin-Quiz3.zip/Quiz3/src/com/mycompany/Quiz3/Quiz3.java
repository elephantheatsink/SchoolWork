package com.mycompany.Quiz3;

import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.Container;

public class Quiz3 extends Form implements ActionListener{
	private Button clickMe=new Button("Click Me"); //name of the button
	
	public Quiz3(){
		this.setLayout(new BorderLayout()); //instantiate BorderLayout
		Container myCont = new Container();	//instantiate Container
		myCont.add(clickMe); //add button to Container
		clickMe.addActionListener(this); //add Listener to button with override
		add(BorderLayout.CENTER , myCont); //add component to center of BorderLayout
		
		clickMe.getAllStyles().setPadding(Component.LEFT, 7); //padding on the left side of button
		
		this.show(); 
	}
	
	public void actionPerformed(ActionEvent evt) { //handling command
		if (evt.getComponent().equals(clickMe)) { //if ActionEvent is click of that button
			System.out.println("Button Pushed..."); //perform this command
		}
	}

}
