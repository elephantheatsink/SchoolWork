package com.mycompany.a3;

public interface ICollection {
	public void add(Object newObject);
	public IIterator getIterator();
}
