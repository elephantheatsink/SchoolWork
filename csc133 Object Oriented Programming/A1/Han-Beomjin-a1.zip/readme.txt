java -cp dist\A1Prj.jar;JavaSE.jar com.codename1.impl.javase.Simulator com.mycompany.a1.Starter

The program should work as it says in the instructions.
The only part of the program that will have to be rewritten in the future is the k, e, c, x, w commands that just removes the first of the specified game object that is in the ArrayList, because the prompt said to not worry about the two game objects being "close" to each other, and that we could choose which game objects are to be removed. So I just removed the first one. That will definitely be changed later.