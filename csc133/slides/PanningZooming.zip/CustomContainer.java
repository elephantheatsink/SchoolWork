package com.mycompany.myapp;

import java.util.Vector;

import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.geom.Point;
import com.codename1.ui.geom.Shape;

public class CustomContainer extends Container {
	Transform worldToND, ndToDisplay, theVTM ;
	Triangle myTriangle;
	private float winLeft, winBottom, winRight, winTop,  winWidth, winHeight;
	private Vector<Shape> shapeCollection;
	public CustomContainer(){
		//initialize world window			
		winLeft = 0;
		winBottom = 0;
		winRight = 931/2; //hardcoded value = this.getWidth()/2 (for the iPad skin)
		winTop = 639/2; //hardcoded value = this.getHeight()/2 (for the iPad skin)
		winWidth = winRight - winLeft;
		winHeight = winTop - winBottom;
		//create shapes
		myTriangle = new Triangle((int)(winHeight/5),(int)(winHeight/5));
		myTriangle.translate(winWidth/2, winHeight/2); 
		myTriangle.rotate(45);
		myTriangle.scale(1, 2);
		//...[create other simple or hierarchical shapes and add them to collection]	
	}
	
	public void paint (Graphics g) {
		Transform gXfrom;
		super.paint(g);
		//...[calculate winWidth and winHeight]
		// construct the Viewing Transformation Matrix
		worldToND = buildWorldToNDXform(winWidth, winHeight, winLeft, winBottom);
		ndToDisplay = buildNDToDisplayXform(this.getWidth(), this.getHeight());
		theVTM =  ndToDisplay.copy();
		theVTM.concatenate(worldToND); // worldToND will be applied first to points!
		// concatenate the VTM onto the g�s current transformation (do not forget to apply �local 		//origin� transformation)
		Transform gXform = Transform.makeIdentity(); 
		g.getTransform(gXform);
		gXform.translate(getAbsoluteX(),getAbsoluteY()); //local origin xform (part 2)
		gXform.concatenate(theVTM); //VTM xform
		gXform.translate(-getAbsoluteX(),-getAbsoluteY()); //local origin xform (part 1)
		g.setTransform(gXform); 
		// tell each shape to draw itself using the g (which contains the VTM)
		Point pCmpRelPrnt = new Point(this.getX(), this.getY());
		Point pCmpRelScrn = new Point(getAbsoluteX(),getAbsoluteY());
		myTriangle.draw(g, pCmpRelPrnt, pCmpRelScrn);
		g.resetAffine() ;
	}
	
	private Transform buildWorldToNDXform(float winWidth, float winHeight, float 	winLeft, float winBottom){
				Transform  tmpXfrom = Transform.makeIdentity();
				tmpXfrom.scale( (1/winWidth) , (1/winHeight) );
				tmpXfrom.translate(-winLeft,-winBottom);
				return tmpXfrom;
			}	
			private Transform buildNDToDisplayXform (float displayWidth, float displayHeight){ 
				Transform tmpXfrom = Transform.makeIdentity();
				tmpXfrom.translate(0, displayHeight);
				tmpXfrom.scale(displayWidth, -displayHeight);
				return tmpXfrom;
			}
		//...[other methods of CustomContainer]
			/* Following methods should be added to CustomContainer to allow zooming and panning */
			public void zoom(float factor) {
				//positive factor would zoom in (make the worldWin smaller), suggested value is 0.05f
				//negative factor would zoom out (make the worldWin larger), suggested value is -0.05f
				//...[calculate winWidth and winHeight]
				float newWinLeft = winLeft + winWidth*factor;
				float newWinRight = winRight - winWidth*factor;
				float newWinTop = winTop - winHeight*factor;
				float newWinBottom = winBottom + winHeight*factor;
				float newWinHeight = newWinTop - newWinBottom;
				float newWinWidth = newWinRight - newWinLeft;
				//in CN1 do not use world window dimensions greater loat newWinHeight = newWinTop - newWinBottom; than 1000!!!
				if (newWinWidth <= (float) 1000 && newWinHeight <= (float) 1000 && newWinWidth > (float) 0 && newWinHeight > (float) 0 ){
					winLeft = newWinLeft;
					winRight = newWinRight;
					winTop = newWinTop;
					winBottom = newWinBottom;
					winWidth = newWinWidth;
					winHeight = newWinHeight;
				}
				else
					System.out.println("Cannot zoom further!");
				this.repaint();

			}
			public void panHorizontal(double delta) {
				//positive delta would pan right (image would shift left), suggested value is 5  
				//negative delta would pan left (image would shift right), suggested value is -5  
				winLeft += delta;
				winRight += delta;
				this.repaint();
			}
			public void panVertical(double delta) {
				//positive delta would pan up (image would shift down), suggested value is 5  
				//negative delta would pan down (image would shift up), suggested value is -5  
				winBottom += delta;
				winTop += delta;
				this.repaint();
			}
			
			/* Override pinch() in CustomContainer to allow zooming with pinching*/
			@Override
			public boolean pinch(float scale){
				if(scale < 1.0){
					//Zooming Out: two fingers come closer together (on actual device), right mouse 	
					//click + drag towards the top left corner of screen (on simulator)
					zoom(-0.05f);
				}else if(scale>1.0){
					//Zooming In: two fingers go away from each other (on actual device), right mouse 			
					//click + 	drag away from the top left corner of screen (on simulator)
					zoom(0.05f);
				}
				return true;
			} 
			
			/* Override pointerDrag() in CustomContainer to allow panning with a pointer drag which is simulated with a mouse drag (i.e., simultaneous mouse left click and mouse movement). Below code moves the world window in the direction of dragging (e.g., dragging the pointer towards left and top corner of the display would move the object towards the right and top corner of the display) */
			private Point pPrevDragLoc = new Point(-1, -1);
			@Override
			public void pointerDragged(int x, int y)
			{
			  if (pPrevDragLoc.getX() != -1)
			  {
				System.out.println("x " + x + " pPrevDragLoc.getX() " + pPrevDragLoc.getX());
				if (pPrevDragLoc.getX() < x) {
					panHorizontal(5);
					System.out.println("Pan horizontal positive 5");
				}	
				else if (pPrevDragLoc.getX() > x) {
					panHorizontal(-5);
					System.out.println("Pan horizontal negative 5");
				}
				if (pPrevDragLoc.getY() < y)
					panVertical(-5);
				else if (pPrevDragLoc.getY() > y)
					panVertical(5);
			  }	
			  pPrevDragLoc.setX(x);
			  pPrevDragLoc.setY(y);
			}

			
}//end of CustomContainer
